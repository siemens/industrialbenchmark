import unittest
from IDS import IDS
import numpy as np

class TestIB(unittest.TestCase):

    def test_example(self):
        # fixed seed for setpoint
        np.random.seed(501)
        p = []
        trajectories = 10
        T = 1000 # perform 1000 actions/ steps

        # generate different values of setpoint
        for value in range(10):
            p.append(np.random.randint(1, 100))

        # perform 1000 actions per trajectory
        for i in range(trajectories):
            # generate IB with fixed seed. If no seed is given, IB is generated with random values
            env = IDS(p[i], inital_seed=1005 + i)

            for j in range(T):
                at = 2 * np.random.rand(3) - 1
                # perform action
                env.step(at)
                markovStates = env.all_states()
                if (j==0):
                    markovStates_all = np.array(markovStates)
                else:
                    markovStates_all = np.vstack([markovStates_all, markovStates])

            #np.savetxt('markovStates_test' + str(i) + '.csv',  markovStates_all, delimiter=',')

            compare_file_markovStates = np.genfromtxt('test_data/markovStates'+str(i)+'.csv', delimiter=',')

            # test if test files and original files are equal
            np.testing.assert_array_almost_equal(compare_file_markovStates, markovStates_all)